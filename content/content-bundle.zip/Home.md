# 👋🏼 Hello there!

# Notes from my classes

Jump to [[Notes]], [[Unit 3]], or [[Daily Quiet Time]]


| ![200 x 200](https://avatars.githubusercontent.com/u/32552207) | <h1>Notes by James</h1> <h3>2022-2023</h3> |
|-|-|
