# ⌚ Daily Quiet Time Journal
###### Journaling through the book of James

## Day 1️⃣
*James 1:19-27*

#### 👁️ Observations

- Contrast: “quick to listen, slow to speak, and slow to become angry”
- Progression: Get rid of moral filthiness/wickedness → receive with humility the word planted in you → save your soul.
- Command: “Be people who do what the word says, not people who only hear it.”
- Action words: “Do, hear, listen, speak, receive”
- Image: “In fact, if anyone hears the word and does not do what it says, he is like a man who carefully looks at his natural face in a mirror. Indeed, he carefully looks at himself; then, he goes away and immediately forgets what he looked like.”
- Reason: “one who looks carefully into the perfect law, the law of freedom, and continues to do so—since he does not hear and forget but does what it says—that person will be blessed”
- Cause and effect: one who looks carefully into the perfect law → will be blessed
- Reason: “considers himself to be religious but deceives his own heart because he does not bridle his tongue”
Repetition: “religion”
- Condition: Religion that is pure and undefiled occurs when one takes care of “the least of these” and keeps oneself unstained by the world.
- Description: “Religion that is pure and undefiled in the sight of God the Father is this: to take care of orphans and widows in their affliction and to keep oneself unstained by the world.”

#### 📖 Interpretation

###### How do we get rid of our moral filthiness/wickedness by receiving God’s Word with humility to save our souls?
God’s Word is clear that we are saved by faith (not by works) and therefore James is not contradicting this at the start of the passage. When we receive God’s Word with humility (in a manner that we are sinners), we can rid ourselves of sin by faith in what His Word tells us - that Jesus shed his blood on the cross to die for our sins and by trusting that we have salvation through His merits (not ours). This is what saves our souls.

###### What does James mean by “be quick to listen, slow to speak, and slow to become angry?”

James is referring to God’s Word when he urges us to be “quick to listen.” He means that we should be quick to listen to God’s Word. In contrast, he commands us to be slow to speak, that is, to consider what we say before we say it, and to be slow to anger, that is, to not become angry at others, but deal with them in Christian kindness and humility.

###### Why does James command us to be more than just “hearers of the Word” but also “doers of the Word?”

James commands us to be doers of the Word and hearers of the Word because if we do not take God’s Word to heart and look at what the law commands us, we forget that we are sinners and in need of a Savior. We also should reflect this in what we say to other people and what we do around others. Therefore, they will recognize that we are living the way we are because God has freed us from sin, not because we can free ourselves from sin.

###### How can we be blessed by continuing to look into the perfect law of God?

We are blessed by continuing to look into the perfect law of God because we then recognize our need for a savior through the act of repentance, and can be saved by looking at the whole law – the law of Grace – that Jesus fulfilled the law in our place so that even though we are sinners, we are saved by what He did for us and not what we did ourselves. From this, good works flow from the restored spirit that He gives us.

###### Why does the language that James uses seem to point us to follow the law, even though we know that we are saved by Grace alone?

James’s language appears this way if the passage is interpreted in a narrow sense. When looking closer, we see that James uses concepts such as the “law of freedom” which cannot mean the Old Testament law (which is a law of slavery and bondage). Rather, James is referring back to the Gospel – salvation is by grace through faith alone. So, when taking a closer look at James’ words and the context of the rest of the Bible, we realize that He is talking about the Gospel as the way of salvation, not the Old Testament law.

## Day 2️⃣
*James 2:1-13*

#### 👁️ Observations

- Command: Have faith without showing favoritism.
- Image: If you would seat a rich man in a good place and a poor man in a low place you have made an evil distinction.
- Contrast: Poor in material things (possessions), rich in faith.
- Description: The rich are oppressive, condemn Christians, and blaspheme God.
- Condition: If you fulfill the law, you do well.
- Progression: Show favoritism > commit sin > become a convict of the law > you are a transgressor.
- Condition: If we break one law, then we are guilty of breaking the whole law.
- Important term: “law of freedom” – in other words, the Gospel – the law that Christ has won salvation.
- Image: No mercy for the one who does not show mercy… mercy triumphs over judgment.
- General to specific: Have faith without showing favoritism > do not make evil distinctions of favoritism > do not hypocritically dishonor the poor.

#### 📖 Interpretation
###### Why does James command us to “have faith without showing favoritism?”

James commands us to “have faith without showing favoritism” because the Gospel is for everyone and favoritism hinders people from the Gospel. If we make an evil distinction by playing favorites with those who are rich, then we make those who are poor feel excluded and keep them from the Gospel because of worldly things. This is most certainly not right to do.

###### What does James mean when he talks about being poor in material things and rich in faith?

In the Gospel, Jesus talks about this topic similarly when He states that it is hard for the rich to enter heaven (because their worldly treasures stand in the way). He also talks about this in the parable concerning Lazarus and the rich man. With this, both James and Jesus are talking about how we should have spiritual desires, not materialistic desires. The poor do not have material things and thus are not able to trust them. This is not to say that we want to be poor in this life, but that we should rather long to be rich in faith and content with what we have in this life.

###### Why does James say that if we break one law, we are guilty of breaking the entire law?

James uses this to cause the reader to realize that they cannot keep the law, period. If we examine ourselves closely, we will see that if we cannot love our neighbor, whom we can see, we cannot love God whom we cannot see. No one can stand to this measure. Only Jesus could stand to this, for He did not break the law in a single part. Here we see that we cannot be saved by the law, only the Gospel can save us.

###### What does James mean by the “law of freedom?”

Here, James is not referring to the original law as given to Moses in the Old Testament because, by the original law, we were enslaved to sin. Rather, James is talking about the law of grace, or the law of the Gospel – that despite our shortcomings and failure to obey God, we are saved and freed through the objective fact that Jesus died to save the world from sin.

###### Why does James tell us that “mercy triumphs over judgment?”

James tells us this to display an attribute of God and encourage us to show mercy as God has shown to us. He displays that God is a merciful God, who could justly condemn us, but has shown us mercy instead by sending His only Son to die for us on the cross. So also, we should show mercy to others, being forgiving and comforting them with the hope they have in Christ.

## Day 3️⃣
*James 2:14-26*

#### 👁️ Observations

- Image: If someone is in need and you send them away with wishes that they will find what they need without giving them what they need, it is no good.
- Condition: Faith, if it is alone without works, is dead.
- Comparison: You believe that God is one, demons believe the same thing – and shudder.
- Image: Abraham’s faith was shown through his work of offering his only son on the altar – He trusted God’s promise.
- Image: Rahab was shown to be righteous in her dealings with the Israelite spies.
- Comparison: Faith without works = dead, just as the body without breath = dead.
- General to specific: Faith requires action > faith cannot be shown without works > faith in God is more than just mere belief > Abraham and Rahab showed their faith through their actions > faith without works is dead.

#### 📖 Interpretation

###### Why does James use the image of a person who sends a person away hoping they find what they need instead of giving them what they need?

James uses this image to show us that faith is active. If we hope someone achieves something or gets a certain thing that they need, we would help them if we truly wanted this for them. Sometimes, we can be lazy to the point that we don’t even see what we need, but have faith that we will get what we need without doing anything. While God provides for all people, he does it in simple ways that often appear miraculous and not like the doing of God. How does God provide for us? Maybe He does it by giving us a job or giving us a caretaker (such as a parent) to care for us. Whatever the situation, faith isn’t just passive – it’s active, working toward the goal that it wants to achieve.

###### What does James mean by “faith without works is dead?”

James continues in this passage to talk about faith as being active. While works certainly do not save us, they are present where faith is present. Jesus tells us to judge a tree by its fruit. If faith does not show its fruit, it is dead just like a tree that does not bear fruit is either dead or about as useful as a dead tree. However, when faith does produce the fruits of good works, it manifests what Christ has done. We do good works, not because we have to, but out of thankfulness. By using our talents (good works), we can bring others to faith in Christ.

###### Why does James say that even demons believe in God and shudder?

Here, James is telling us of mere belief which is no faith at all. Believing in the mere existence of God is not what saves. In fact, we are in the same terror that the demons are in when we merely believe that God is real because we understand that we rightly deserve His wrath. However, faith is not just mere belief, but belief that clings to the hope in God’s promise to save us. This faith, which He gives us, is how we are saved – by His grace.

###### Why does James use Abraham and Rahab as examples of how faith is active?

James uses Abraham and Rahab for two good reasons. First of all, if we examine the lives of both Abraham and Rahab, we see that they were both sinful people. We know that Abraham committed adultery and also distrusted God’s promise when he had a son with his servant when God promised that he would have a son with Sarah. On the other hand, we are told that Rahab was a prostitute, and thus a sinner as well. However, despite their sin, both of them came to trust God’s promise. For Abraham, it was the promise that the nations of the earth would be blessed through his descendants. When offering his son on the altar at God’s command, he displayed that he trusted God would make His promise happen even if it seemed impossible – everything is possible with God. Rahab also showed her faith by trusting in the promise that she would be saved from death if she helped the Israelites.

## Day 4️⃣
*James 3:1-12*

#### 👁️ Observations

- Command: Not many of you should become teachers.
- Condition: If anyone does not stumble in what they say, they are a mature man.
- Comparison: We use bits in the mouths of horses and small rudders to control large ships. The tongue is similarly a small part that boasts of great things.
- Comparison: A small flame can set a forest on fire. Likewise, the tongue is a flame that sets the body and the entire course of life on fire.
- Contrast: Every animal is being tamed by mankind, but no one can tame the human tongue.
- Contrast: With our mouths, we both bless and curse (it should not be this way)
- Image: A spring does not pour out both fresh and bitter water, nor does a fig tree bear olives or a grapevine bear figs.
- Image: A salt spring cannot produce fresh water either.

#### 📖 Interpretation

###### Why does James suggest that not many of us should become teachers (pastors)?

James suggests that not all of us should become teachers (pastors) because not all of us are called or qualified to become a teacher. Just as God has called us to faith, God calls certain people to serve His sheep. The word “pastor” comes from the Latin word for “shepherd.” Paul tells us in 1 Timothy 3 how pastors (teachers) should behave.

###### Why does James say that a person who does not stumble in what they say is mature?

James tells us that a person who does not stumble in what they say is mature because our tongues are hard to control - they are tainted by sin. In reality, no one is mature because we have all sinned with our tongues. We have spoken in hate and we have been deceitful. No one is perfect in their speech and thus no one is mature in what they do.

###### Why does James compare our tongues to a flame?

James compares our tongues to a flame, which can set a whole forest on fire. Our tongues often boast of great things and we often use them to deceive others with lies. This boasting and lying, especially if we frequently do such, can turn our lives into a disaster. Our continued failure to do as we promise and to be as we boast can lead us to a life of misery. Luckily, God sent His Son, Jesus, to save us from our failures in not only what we say, but also in what we do and think.

###### What is James talking about when he says that both curse and praise come out of the same mouth?

While our mouths are used to praise our God, we often use them for cursing others. James notes this hypocrisy, we praise God one moment and the next moment we curse those who are made in the image of God. This should not be so, for how can we think we love God and yet harbor hate and anger against our neighbor? Because we need to love our neighbor as well, to love God (for we do not love God, if we do not keep his command to love our neighbors), we fall short and truly do not love either. However, we find consolation in God’s Word, that despite our hypocrisy – He saved us by His good grace.

###### What do James’s images represent when he tells us that “grapevines do not bear figs” and “salt springs do not bear fresh water?”

Similar to how Jesus tells us that we are either for Him or against Him, James uses these images to show that blessing and cursing cannot come out of the same mouth. The mouth either only sins or only does good – and we as imperfect people, only sin with our mouths. We are unable to do anything good without God. However, in Christ, we can bless both God and our neighbor – even if they are our enemies because God has given us the ability to love and display the love that Christ has for us.

## Day 5️⃣
*James 3:13-18*

#### 👁️ Observations

- Command: Let the wise and intelligent show that they are so by their good way of living and humility.
- Condition + Command: If you have bitter envy or selfish ambition, do not boast or lie, contrary to the truth.
- Contrast: Wisdom from above is pure, gentle, reasonable, merciful, impartial, and sincere. Worldly wisdom is bitter, selfish, boastful, deceitful, unspiritual, and demonic.
- Explanation: This (boasting and lying) is not wisdom from above, but worldly wisdom that is unspiritual and demonic.
- Reason: Where there is envy and selfish ambition, there is also disorder and every bad practice.
- Explanation: Spiritual wisdom is, “first pure, then also peaceful, gentle, reasonable, full of mercy and good fruits, impartial, and sincere.”
- Reason: A harvest of righteousness is sown in peace by those who practice peace.

#### 📖 Interpretation

###### Why does James command the wise and intelligent to show that they are so by the way they live?

In this passage, as well as the previous one, James talks a great deal about how actions speak louder than words, or that our actions determine whether we are or are not a certain way. It’s reasonable to suggest that those who are wise should live as such and those who are intelligent should live as such as well. However, most people who claim that they are this way, often are quite the opposite. You and I can fall into that category. Only God is truly wise and intelligent, and He is also merciful in that He forgives us for being hypocrites in this manner.

###### For what reason does James command us to not boast or lie, even if we are envious or selfish?

While it should be obvious that we should obey this command, we often do not. We boast because we envy someone else as if doing such lightens our feeling of envy (but rather, the opposite happens, and we engage in envying others even more). We lie because we are selfishly ambitious, thinking that our mouth will exalt us, but rather brings us into judgment because we did not deliver what we claimed to do. Therefore, James tells us this for a good reason, so that we do not continue to do this and so that we realize that we have failed at this and need God’s help.

###### How can we tell if wisdom is spiritual and from above?

James gives us a list for us to determine whether wisdom is spiritual or not. He tells us that spiritual wisdom is “pure, peaceful, gentle, reasonable, merciful, fruitful, impartial, and sincere.” When we look at this, we can see that we are not spiritually wise in the flesh, but God is spiritually wise and He gives this spiritual wisdom to us in His Word.

###### How can we tell if wisdom is worldly and not from above?

James also gives us a list to describe the attributes of worldly, unspiritual wisdom. He tells us that worldly wisdom is bitter, selfish, boastful, deceitful, unspiritual, and demonic. He also tells us that boasting and lying are worldly wisdom that is not from above. When we see this, we understand that we have often embraced worldly wisdom and shunned the spiritual wisdom from above in favor of such.

###### Why are there bad practices and disorders where bitter envy and selfish ambitions abound?

Where there is selfish ambition, there is a lack of caring for others and a loss of morality because one will do whatever it takes to exalt themselves at the expense of others. Where there is bitter envy, there is lying, stealing, theft, and deceit – for once we desire something, we do not rest until we have it. From this, disorder and bad practices erupt because everyone attempts to exalt themselves and no one cares about others. Despite this, God cared for you and me so that we wouldn’t have to bear the punishment for our ill behavior. Rather Jesus bore the punishment for all of our disorder and bad practices on the cross.

## Day 6️⃣
*James 4:1-12*

#### 👁️ Observations

- Reason: Conflicts and quarrels among you come from your cravings for pleasure which is at war within you.
- Progression: You want something > but you do not get it > so you murder.
- Progression: You desire something > but you cannot obtain it > so you quarrel and fight.
- Reason: You do not have because you do not ask.
- Progression: You ask > yet do not receive > because you ask wrongly (for personal pleasure).
- Contrast: Friendship with the world means hostility toward God.
- Contrast: God opposes the proud but gives grace to the humble.
- Commands: Submit yourselves to God, resist the devil, come near God, cleans your hands, purify your hearts. Lament, mourn, weep, let your laughter be mourning and your joy, gloom. Humble yourselves in the sight of the Lord.

#### 📖 Interpretation

###### Where do conflicts and quarrels come from according to James?

James tells us that conflicts and quarrels come from our cravings for pleasure which are at war within us. When we desire something, it is often an evil desire which, out of our selfishness, want it immediately. So, we cause a conflict, pit people against each other, and quarrel to get our way. We know that we should not do such, but we often ignore our conscience and do it anyway.

###### Why do we lack the things that we need?

We lack things that we need because we do not ask for what we need. Instead of asking for our spiritual needs, we may often pray for worldly needs, because we are materialistic and too concerned with earthly pleasures than our faith. Therefore, we lack what we need spiritually because we do not ask for our spiritual needs.

###### Why do we sometimes not get the things we ask for from God?

Sometimes, we do not get the things that we ask for from God because we ask for the wrong things. God is willing to give us all that we ask for concerning our spiritual needs, but sometimes it is not His will for us to get those things which we ask for that are worldly needs. Sometimes, we may ask for or want the wrong things from God. God desires that we grow in spiritual wealth and not in earthly wealth.

###### Why does friendship with the world mean hostility toward God?

The world is hostile and indifferent toward God. Jesus tells us that His kingdom is not of this world and that this world will pass away. Friendship with the world means that we trust in the world and carnal pleasures. These things are hostile toward God and evil in His sight.

###### Why does God oppose the proud and give grace to the humble?

God opposes the proud because they oppose Him and His will. The proud boast in worldly things and trust in their possessions and power. Historically, such as when the Israelites were in Babylon, God showed his opposition to the proud by overthrowing them. In contrast, God gives grace to the humble, those who recognize their need for Jesus and their discontentedness with worldly pleasures.

## Day 7️⃣
*James 4:13-5:8*

#### 👁️ Observations

- Command: Do not speak against one another.
- Cause and effect: If you judge the law, you are not the one who does the law, but a judge.
- Image: Your life is a mist that appears for a little while and then disappears.
- Reason: It is a sin for the one who knows the right thing to do and doesn’t do it.
- Image: Your wealth has rotted and moths have eaten up your clothes.
- Cause and effect: You (the rich) have lived for pleasure on earth and led a life of luxury, fattening your hearts on the day of slaughter. Because you condemned and murdered the Righteous One, he now opposes you.
- Command: Be patient until the coming of the Lord.
- Image: Be patient, just as the farmer waits for the valuable harvest from the ground.
- Command: Strengthen your hearts because the coming of the Lord is near.

#### 📖 Interpretation

###### Why does James command us not to speak against one another?

As Christians, we should not oppose one another, so that we do not drive each other away from Christ. James urges us to not speak against each other for two good reasons. First of all, it’s hypocritical to judge someone for being a sinner when we are sinners. Second, we should not want to be the obstacle keeping someone from the throne of grace, therefore, we should not speak against one another, but rather build each other up in the light of God’s grace.

###### Why should we not judge others based on the law?

James tells us that one who judges the law does not do the law, but is simply a judge. When we judge others based on the law, we are hypocrites like the Pharisees. Remember how the Pharisees attempted to judge Jesus based on their narrow and hollow idea of the law? In the same way, it’s hypocritical for us to judge others because we do not keep the law. Rather, we should trust in what God has done for us and bring those we have considered judging into the light of God’s grace because all have fallen short of His glory but are justified freely by His grace.

###### Why is our life a mist?

Our life is a mist because it is infinitely small when comparing it with eternity. It appears for a little while but then disappears. Our handful of years that we live here is incomparable with the eternal amount of time that we will spend in one of two places when we pass away. However, by the grace of God, you and I will escape eternal punishment to join our Lord in heaven because of what He graciously did for us. Therefore, James uses this to urge us to keep steadfast in our faith and God’s word.

###### Why is it a sin for us to not do the right thing?

When we sin by not doing something that we should do, it is called a sin of omission or a sin of omitting what God has commanded us to do. So, if we knew someone was in dire need and did nothing to save them, we sinned because we did not do what we knew we should have done. This leads us to further realize that keeping the law is impossible beyond impossible for us in sinful flesh.

###### Why are we told to be patient and strong until God’s coming?

We are told to be patient and strong until God’s coming because we are at constant war with the world, the devil, and our sinful flesh. For this reason, we need to be constantly reminded that we need God’s grace and that we are saved by the faith that He gives us. Therefore, we should continue in our lives, being faithful to God and fearing nothing because we do not know when He will come, whether He takes us by death or whether He comes again, we do not know the plans that He has for us, but we do know that He has saved us.
