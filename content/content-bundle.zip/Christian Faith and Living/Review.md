# Important Terms

-   Christian
    
    A person who believes what the Bible teaches about Jesus Christ, has accepted him as their Savior, and is seeking to live as he leads.
    
-   Faith
    
    Active trust in God—not just believing that he exists, but that what he promised is true and worthy of personal commitment.
    
-   Lost
    
    The condition of being separated from God.
    
-   Saved
    
    To be restored to a loving, trusting relationship with God.
    
-   Born Again
    
    The spiritual awakening that occurs when a person recognizes they have been lost and embraces a restored relationship with God.
    
-   Lordship
    
    The exercise of authority over someone or something.
    
-   Disciple
    
    A person who is devoted to becoming like Jesus.
    
-   Rabbi
    
    A Jewish scholar, teacher, and spiritual leader.
    
-   Human
    
    An eternal being created by God to reflect his image.
    
-   Catechism
    
    A set of questions and answers used as a tool to teach the doctrines of a church.
    
-   Spiritual Discipline
    
    Practices found in scripture that promote spiritual growth.
    
-   Concordance
    
    An alphabetical list of words included in the Bible showing where they can be found.
    
-   Inductive Study
    
    A form of study that reaches conclusions based on observation.
    
-   Prayer
    
    Communication with God.
    
-   Christian Worship
    
    Valuing or treasuring God above all things. Showing or displaying the worth of God.
    
-   Tithe
    
    A Hebrew word meaning a tenth.
    
-   Sin
    
    Any act in rebellion against God.
    
-   Confess
    
    To agree with God that what I have done is wrong.
    
-   Repent
    
    To repent is to acknowledge, or to have sorrow, that you have done wrong (that you have sinned) and to receive absolution or forgiveness for what you have done wrong. 
    
    (*Note: not official definition, do consider changing*)
    
-   Spiritual Fast
    
    A period of humbling oneself through self-denial for the purpose of being better able to hear from God.
    
-   Calling
    
    A God given passion to pursue a particular career or course of action.
    
-   The Church
    
    The church is people. It consists of all people living and dead, who have accepted Jesus Christ as their Lord and Savior.
    
-   A church
    
    A church is a group of Christians that meet in a particular time and place for worship and fellowship.
    
-   Koinonia
    
    A deep and intimate fellowship that unites Christians.
    
-   Doubt
    
    A struggle to believe or have faith.
    
-   Temptation
    
    the intentional enticement of a person to disobey God’s revealed Word.
    
-   Stress
    
    A feeling of emotional or physical tension that is triggered by events or thoughts that cause you to feel frustrated, angry, or nervous.
    
-   Materialism
    
    A tendency to consider material possessions and physical comfort as more important than spiritual values.
    
-   Influence
    
    The capacity to have an effect on the character, development, or behavior of someone or something.
    
-   Conform
    
    To act in accord with the prevailing standards, attitudes, and practices of society
    
-   Transform
    
    to change form to become something of different form or shape.
    
-   Pride
    
    An attitude of self-sufficiency, self-importance, and self-exaltation in relation to God, and an attitude of contempt and indifference to others.
    
-   Humility
    
    Having a right view of ourselves in relation to God and others, and acting accordingly.
    
-   Forgiveness
    
    A conscious, deliberate decision to release feelings of resentment or vengeance toward a person or group who has harmed you, regardless of whether or not they deserve it.
    
-   Habitual Sin
    
    A sin that continues to be repeated
    
-   Spiritual Maturity
    
    Becoming more like Christ in every way
    
-   Spiritual Milk
    
    The basic principles of God’s teaching
    
-   Solid Food
    
    Teaching for those who are actively living by faith.
    
-   Wisdom
    
    The ability to use your knowledge and experience to make good decisions and judgments
    
-   Christian Leadership
    
    The act of enabling other people to fulfill the purposes of God in and through them.
    
-   Walk in the Spirit
    
    To give control of your words, thoughts, and actions to the Holy Spirit
    
-   _Agape_
    
    -An entirely unselfish and giving love.

# Memory Verses

## Ephesians 2:8-9

Indeed, it is by grace you have been saved, through faith - and this is not from yourselves, it is the gift of God - not by works, so that no one can boast.

## Acts 4:12

There is salvation in no one else, for there is no other name under heaven given to people by which we must be saved.

## John 15:13

No one has greater love than this: that someone lays down his life for his friends.

## 1 John 1:8-9

If we say we have no sin, we deceive ourselves, and the truth is not in us. If we confess our sins, he is faithful and just to forgive us our sins and to cleanse us from all unrighteousness.

## Psalm 24:1-2

The earth is the Lord's and everything that fills it, the world and all who live in it, because he founded it on the seas, and he established it on the rivers.

## Genesis 2:24

For this reason a man will leave his father and his mother and will remain united with his wife, and they will become one flesh.

## Hebrews 10:24-25

Let us also consider carefully how to spur each other on to love and good works. Let us not neglect meeting together, as some have the habit of doing. Rather, let us encourage each other, and all the more as you see the Day approaching.

## Matthew 7:12

So do for others whatever you want people to do for you, because this is the Law and the Prophets.

## Matthew 11:28-30

“Come to me all you who are weary and burdened, and I will give you rest. Take my yoke upon you and learn from me, because I am gentle and humble in heart, and you will find rest for your souls. For my yoke is easy and my burden is light.”

## Matthew 6:33

But seek first the kingdom of God and his righteousness, and all these things will be given to you as well.

## Ephesians 4:32

Instead, be kind and compassionate to one another, forgiving one another, just as God in Christ has forgiven us.

## Matthew 28:19-20

"Therefore go and gather disciples from all nations by baptizing them in the name of the Father and of the Son and of the Holy Spirit, and by teaching them to keep all the instructions I have given you. And surely I am with you always until the end of the age.”