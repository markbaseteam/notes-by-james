# ✝️ Christian Faith and Living

## Notes and Projects
- #### [[Unit 3]]
- #### [[Daily Quiet Time]]
- #### [[Review]]

