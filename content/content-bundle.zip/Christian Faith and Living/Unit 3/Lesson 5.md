# Family 👨🏼‍👩🏼‍👦🏼‍👧🏼
- **Why is it significant that Eve was made from Adam’s rib?**
	- It shows that they shared the same essence
- **Why did God create Eve?**
	- Because it was not good for man to be alone
- **Which of the following were characteristics of the first family before they rebelled against God?**
	- They were one flesh
	- They were not ashamed
	- They could share their thoughts without fear
- **Memory Verse: Genesis 2:24**
	- For this reason a man will leave his father and his mother and remain united with his wife, and they will become one flesh.
- **What happened to the first family when they ate the forbidden fruit?**
	- They felt a new emotion of shame
	- They blamed each other
	- They competed for dominance
- **What did Jesus say about divorce in Matthew 19:3-12?**
	- He quoted Genesis 2:24
	- It is not how things were in the beginning
	- The law allows it because of people's hard hearts
- **Why is the family portrayed in Ephesians 5:22-6:4 different than other families?**
	- Christ is present in this family
	- This family is an image of the relationship between Christ and his church
- **List at least five ways in which a Christian family can reflect the relationship between Christ and his church.**
	1. Give respect, not blame.  
	2. Love sacrificially.  
	3. Cherish, not resent.  
	4. Honoring, not rebelling.  
	5. Discipline, don't provoke.